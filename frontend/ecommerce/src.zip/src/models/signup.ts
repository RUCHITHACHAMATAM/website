export class SignUp {
    constructor(public userName: string, public email: string, public password: string) { }

}