export class Rating {

    public constructor(private rate: number, private count: number) {

    }
}