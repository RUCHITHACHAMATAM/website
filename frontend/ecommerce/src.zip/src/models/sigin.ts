export class SignIn {
    constructor(public userName: string, public password: string) { }

}