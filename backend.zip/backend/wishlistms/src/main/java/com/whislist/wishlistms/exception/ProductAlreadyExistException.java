package com.whislist.wishlistms.exception;

public class ProductAlreadyExistException extends Exception {
    public ProductAlreadyExistException(String msg) {
        super(msg);
    }
}
