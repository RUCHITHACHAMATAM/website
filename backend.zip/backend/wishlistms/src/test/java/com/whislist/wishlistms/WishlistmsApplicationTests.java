package com.whislist.wishlistms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WishlistmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
